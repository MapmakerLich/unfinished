<?xml version="1.0" encoding="UTF-8"?>
<tileset name="patformkenney-16-4x39" tilewidth="16" tileheight="16">
 <image source="patformkenney-16-4x39.png" width="64" height="624"/>
</tileset>

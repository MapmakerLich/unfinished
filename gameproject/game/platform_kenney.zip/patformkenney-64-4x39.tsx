<?xml version="1.0" encoding="UTF-8"?>
<tileset name="patformkenney-64-4x39" tilewidth="64" tileheight="64">
 <image source="patformkenney-64-4x39.png" width="256" height="2096"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset name="patformkenney-32-4x39" tilewidth="32" tileheight="32">
 <image source="patformkenney-32-4x39.png" width="128" height="1248"/>
</tileset>
